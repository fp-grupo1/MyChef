﻿namespace trabalhoGrupoClasses
{
    partial class InfoNutricional
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAnterior = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCusto = new System.Windows.Forms.TextBox();
            this.lblCusto = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnPesquisa = new System.Windows.Forms.Button();
            this.txtPeso = new System.Windows.Forms.TextBox();
            this.txtNomeProduto = new System.Windows.Forms.TextBox();
            this.txtCodigoID = new System.Windows.Forms.TextBox();
            this.lblCodigoID = new System.Windows.Forms.Label();
            this.lblNomeProduto = new System.Windows.Forms.Label();
            this.lblPeso = new System.Windows.Forms.Label();
            this.nupProteina = new System.Windows.Forms.NumericUpDown();
            this.nudLipidos = new System.Windows.Forms.NumericUpDown();
            this.nudHidratosdeCarbono = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.gbAlergenios = new System.Windows.Forms.GroupBox();
            this.rbAlergeniosNao = new System.Windows.Forms.RadioButton();
            this.rbAlergeniosSim = new System.Windows.Forms.RadioButton();
            this.lblHidratosdeCarbono = new System.Windows.Forms.Label();
            this.lblLipidos = new System.Windows.Forms.Label();
            this.lblProteina = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblInformacaoNutricional = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nupProteina)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLipidos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudHidratosdeCarbono)).BeginInit();
            this.gbAlergenios.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnAnterior
            // 
            this.btnAnterior.Location = new System.Drawing.Point(26, 25);
            this.btnAnterior.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAnterior.Name = "btnAnterior";
            this.btnAnterior.Size = new System.Drawing.Size(45, 33);
            this.btnAnterior.TabIndex = 99;
            this.btnAnterior.Text = "<";
            this.btnAnterior.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(22, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 24);
            this.label3.TabIndex = 98;
            this.label3.Text = "Produtos";
            // 
            // txtCusto
            // 
            this.txtCusto.Location = new System.Drawing.Point(777, 154);
            this.txtCusto.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCusto.Name = "txtCusto";
            this.txtCusto.Size = new System.Drawing.Size(115, 22);
            this.txtCusto.TabIndex = 97;
            // 
            // lblCusto
            // 
            this.lblCusto.AutoSize = true;
            this.lblCusto.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCusto.Location = new System.Drawing.Point(773, 125);
            this.lblCusto.Name = "lblCusto";
            this.lblCusto.Size = new System.Drawing.Size(51, 19);
            this.lblCusto.TabIndex = 96;
            this.lblCusto.Text = "Custo";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(897, 156);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(14, 16);
            this.label6.TabIndex = 95;
            this.label6.Text = "€";
            // 
            // btnPesquisa
            // 
            this.btnPesquisa.Location = new System.Drawing.Point(138, 150);
            this.btnPesquisa.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnPesquisa.Name = "btnPesquisa";
            this.btnPesquisa.Size = new System.Drawing.Size(76, 29);
            this.btnPesquisa.TabIndex = 94;
            this.btnPesquisa.Text = "Pesquisa";
            this.btnPesquisa.UseVisualStyleBackColor = true;
            // 
            // txtPeso
            // 
            this.txtPeso.Location = new System.Drawing.Point(616, 154);
            this.txtPeso.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPeso.Name = "txtPeso";
            this.txtPeso.Size = new System.Drawing.Size(115, 22);
            this.txtPeso.TabIndex = 93;
            // 
            // txtNomeProduto
            // 
            this.txtNomeProduto.Location = new System.Drawing.Point(249, 154);
            this.txtNomeProduto.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNomeProduto.Name = "txtNomeProduto";
            this.txtNomeProduto.Size = new System.Drawing.Size(328, 22);
            this.txtNomeProduto.TabIndex = 92;
            // 
            // txtCodigoID
            // 
            this.txtCodigoID.Location = new System.Drawing.Point(26, 154);
            this.txtCodigoID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCodigoID.Name = "txtCodigoID";
            this.txtCodigoID.Size = new System.Drawing.Size(107, 22);
            this.txtCodigoID.TabIndex = 91;
            // 
            // lblCodigoID
            // 
            this.lblCodigoID.AutoSize = true;
            this.lblCodigoID.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodigoID.Location = new System.Drawing.Point(23, 125);
            this.lblCodigoID.Name = "lblCodigoID";
            this.lblCodigoID.Size = new System.Drawing.Size(83, 19);
            this.lblCodigoID.TabIndex = 90;
            this.lblCodigoID.Text = "Código ID";
            // 
            // lblNomeProduto
            // 
            this.lblNomeProduto.AutoSize = true;
            this.lblNomeProduto.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeProduto.Location = new System.Drawing.Point(246, 125);
            this.lblNomeProduto.Name = "lblNomeProduto";
            this.lblNomeProduto.Size = new System.Drawing.Size(113, 19);
            this.lblNomeProduto.TabIndex = 89;
            this.lblNomeProduto.Text = "Nome Produto";
            // 
            // lblPeso
            // 
            this.lblPeso.AutoSize = true;
            this.lblPeso.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPeso.Location = new System.Drawing.Point(612, 125);
            this.lblPeso.Name = "lblPeso";
            this.lblPeso.Size = new System.Drawing.Size(46, 19);
            this.lblPeso.TabIndex = 88;
            this.lblPeso.Text = "Peso";
            // 
            // nupProteina
            // 
            this.nupProteina.Location = new System.Drawing.Point(114, 316);
            this.nupProteina.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.nupProteina.Name = "nupProteina";
            this.nupProteina.Size = new System.Drawing.Size(84, 22);
            this.nupProteina.TabIndex = 87;
            // 
            // nudLipidos
            // 
            this.nudLipidos.Location = new System.Drawing.Point(320, 316);
            this.nudLipidos.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.nudLipidos.Name = "nudLipidos";
            this.nudLipidos.Size = new System.Drawing.Size(84, 22);
            this.nudLipidos.TabIndex = 86;
            // 
            // nudHidratosdeCarbono
            // 
            this.nudHidratosdeCarbono.Location = new System.Drawing.Point(643, 313);
            this.nudHidratosdeCarbono.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.nudHidratosdeCarbono.Name = "nudHidratosdeCarbono";
            this.nudHidratosdeCarbono.Size = new System.Drawing.Size(84, 22);
            this.nudHidratosdeCarbono.TabIndex = 85;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gray;
            this.label5.Location = new System.Drawing.Point(259, 405);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 16);
            this.label5.TabIndex = 84;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gray;
            this.label4.Location = new System.Drawing.Point(259, 382);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(644, 16);
            this.label4.TabIndex = 83;
            this.label4.Text = "Disclaimer: É necessário e obrigatório informar o cliente sobre a existência de a" +
    "lergénios no produto.";
            // 
            // gbAlergenios
            // 
            this.gbAlergenios.Controls.Add(this.rbAlergeniosNao);
            this.gbAlergenios.Controls.Add(this.rbAlergeniosSim);
            this.gbAlergenios.Location = new System.Drawing.Point(26, 375);
            this.gbAlergenios.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbAlergenios.Name = "gbAlergenios";
            this.gbAlergenios.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbAlergenios.Size = new System.Drawing.Size(172, 65);
            this.gbAlergenios.TabIndex = 82;
            this.gbAlergenios.TabStop = false;
            this.gbAlergenios.Text = "Alergénios";
            // 
            // rbAlergeniosNao
            // 
            this.rbAlergeniosNao.AutoSize = true;
            this.rbAlergeniosNao.Location = new System.Drawing.Point(88, 30);
            this.rbAlergeniosNao.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rbAlergeniosNao.Name = "rbAlergeniosNao";
            this.rbAlergeniosNao.Size = new System.Drawing.Size(54, 20);
            this.rbAlergeniosNao.TabIndex = 1;
            this.rbAlergeniosNao.TabStop = true;
            this.rbAlergeniosNao.Text = "Não";
            this.rbAlergeniosNao.UseVisualStyleBackColor = true;
            // 
            // rbAlergeniosSim
            // 
            this.rbAlergeniosSim.AutoSize = true;
            this.rbAlergeniosSim.Location = new System.Drawing.Point(5, 30);
            this.rbAlergeniosSim.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rbAlergeniosSim.Name = "rbAlergeniosSim";
            this.rbAlergeniosSim.Size = new System.Drawing.Size(51, 20);
            this.rbAlergeniosSim.TabIndex = 0;
            this.rbAlergeniosSim.TabStop = true;
            this.rbAlergeniosSim.Text = "Sim";
            this.rbAlergeniosSim.UseVisualStyleBackColor = true;
            // 
            // lblHidratosdeCarbono
            // 
            this.lblHidratosdeCarbono.AutoSize = true;
            this.lblHidratosdeCarbono.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHidratosdeCarbono.Location = new System.Drawing.Point(445, 316);
            this.lblHidratosdeCarbono.Name = "lblHidratosdeCarbono";
            this.lblHidratosdeCarbono.Size = new System.Drawing.Size(160, 19);
            this.lblHidratosdeCarbono.TabIndex = 81;
            this.lblHidratosdeCarbono.Text = "Hidratos de Carbono";
            // 
            // lblLipidos
            // 
            this.lblLipidos.AutoSize = true;
            this.lblLipidos.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLipidos.Location = new System.Drawing.Point(233, 316);
            this.lblLipidos.Name = "lblLipidos";
            this.lblLipidos.Size = new System.Drawing.Size(62, 19);
            this.lblLipidos.TabIndex = 80;
            this.lblLipidos.Text = "Lípidos";
            // 
            // lblProteina
            // 
            this.lblProteina.AutoSize = true;
            this.lblProteina.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProteina.Location = new System.Drawing.Point(22, 316);
            this.lblProteina.Name = "lblProteina";
            this.lblProteina.Size = new System.Drawing.Size(71, 19);
            this.lblProteina.TabIndex = 79;
            this.lblProteina.Text = "Proteína";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gray;
            this.label2.Location = new System.Drawing.Point(21, 268);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(377, 16);
            this.label2.TabIndex = 78;
            this.label2.Text = " Informar sempre o cliente quando requisitados os valores.";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gray;
            this.label1.Location = new System.Drawing.Point(24, 245);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(617, 16);
            this.label1.TabIndex = 77;
            this.label1.Text = "Disclaimer: Todos os valores apresentados estão representados em valores médios e" +
    " não totais.";
            // 
            // lblInformacaoNutricional
            // 
            this.lblInformacaoNutricional.AutoSize = true;
            this.lblInformacaoNutricional.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInformacaoNutricional.Location = new System.Drawing.Point(22, 210);
            this.lblInformacaoNutricional.Name = "lblInformacaoNutricional";
            this.lblInformacaoNutricional.Size = new System.Drawing.Size(224, 24);
            this.lblInformacaoNutricional.TabIndex = 76;
            this.lblInformacaoNutricional.Text = "Informação Nutricional";
            // 
            // InfoNutricional
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(932, 463);
            this.Controls.Add(this.btnAnterior);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtCusto);
            this.Controls.Add(this.lblCusto);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnPesquisa);
            this.Controls.Add(this.txtPeso);
            this.Controls.Add(this.txtNomeProduto);
            this.Controls.Add(this.txtCodigoID);
            this.Controls.Add(this.lblCodigoID);
            this.Controls.Add(this.lblNomeProduto);
            this.Controls.Add(this.lblPeso);
            this.Controls.Add(this.nupProteina);
            this.Controls.Add(this.nudLipidos);
            this.Controls.Add(this.nudHidratosdeCarbono);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.gbAlergenios);
            this.Controls.Add(this.lblHidratosdeCarbono);
            this.Controls.Add(this.lblLipidos);
            this.Controls.Add(this.lblProteina);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblInformacaoNutricional);
            this.Name = "InfoNutricional";
            this.Text = "Informação Nutricional";
            ((System.ComponentModel.ISupportInitialize)(this.nupProteina)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLipidos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudHidratosdeCarbono)).EndInit();
            this.gbAlergenios.ResumeLayout(false);
            this.gbAlergenios.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAnterior;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtCusto;
        private System.Windows.Forms.Label lblCusto;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnPesquisa;
        private System.Windows.Forms.TextBox txtPeso;
        private System.Windows.Forms.TextBox txtNomeProduto;
        private System.Windows.Forms.TextBox txtCodigoID;
        private System.Windows.Forms.Label lblCodigoID;
        private System.Windows.Forms.Label lblNomeProduto;
        private System.Windows.Forms.Label lblPeso;
        private System.Windows.Forms.NumericUpDown nupProteina;
        private System.Windows.Forms.NumericUpDown nudLipidos;
        private System.Windows.Forms.NumericUpDown nudHidratosdeCarbono;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox gbAlergenios;
        private System.Windows.Forms.RadioButton rbAlergeniosNao;
        private System.Windows.Forms.RadioButton rbAlergeniosSim;
        private System.Windows.Forms.Label lblHidratosdeCarbono;
        private System.Windows.Forms.Label lblLipidos;
        private System.Windows.Forms.Label lblProteina;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblInformacaoNutricional;
    }
}